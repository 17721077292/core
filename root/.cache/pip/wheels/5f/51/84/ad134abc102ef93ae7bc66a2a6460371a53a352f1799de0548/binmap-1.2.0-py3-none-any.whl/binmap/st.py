from binmap import types

_b = types.boolean
c = types.char
d = types.double
f = types.floating
e = types.halffloat
i = types.integer
l = types.long  # noqa: E741
q = types.longlong
x = types.pad
p = types.pascalstring
h = types.short
b = types.signedchar
s = types.string
B = types.unsignedchar
I = types.unsignedinteger  # noqa: E741
L = types.unsignedlong
Q = types.unsignedlonglong
H = types.unsignedshort
