from dash.dash_table.FormatTemplate import *  # noqa: F401, F403, E402
